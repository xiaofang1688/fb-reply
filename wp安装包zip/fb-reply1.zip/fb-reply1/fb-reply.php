<?php
/*
Plugin Name: fb-reply
Plugin URI: https://www.fang1688.cn/study-code/2332.html
Description:wordpress评论可见内容插件
Version: 1.0
Author: 方包
Author URI: http://www.fang1688.cn
License: GPLv2
*/

//设置时区为 亚洲/上海
date_default_timezone_set('Asia/Shanghai');




//文章内容回复可见
add_shortcode('reply', 'reply_to_read');
 
function reply_to_read($atts, $content=null) {
extract(shortcode_atts(array("notice" => '<div class="reply-to-read"><p>温馨提示：此处内容需要<a href="#respond" title="评论本文">评论本文</a>后刷新页面才能查看。</p></div>'), $atts));
$email = null;
$user_ID = (int) wp_get_current_user()->ID;
if ($user_ID > 0) {
$email = get_userdata($user_ID)->user_email;
//对博主直接显示内容
$admin_email = "server-c@qq.com"; //<span style="color: #0000ff;">博主Email</span>
if ($email == $admin_email) {
return $content;
}
} else if (isset($_COOKIE['comment_author_email_' . COOKIEHASH])) {
$email = str_replace('%40', '@', $_COOKIE['comment_author_email_' . COOKIEHASH]);
} else {
return $notice;
}
if (empty($email)) {
return $notice;
}
global $wpdb;
$post_id = get_the_ID();
// echo $post_id;
$query = "SELECT `comment_ID` FROM {$wpdb->comments} WHERE `comment_post_ID`={$post_id} and `comment_approved`='1' and `comment_author_email`='{$email}' LIMIT 1";
if ($wpdb->get_results($query)) {
return do_shortcode($content);
} else {
return $notice;
}

}


//自定义引用样式表
function hc_enqueue_style() {
	wp_enqueue_style( 'core', plugins_url('css/fbao_reply.css', __FILE__) , false ); 
} 

//引用文件的钩子
add_action( 'wp_enqueue_scripts', 'hc_enqueue_style' );